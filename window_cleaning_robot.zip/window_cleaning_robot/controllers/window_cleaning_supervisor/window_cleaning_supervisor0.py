from controller import Supervisor
import numpy as np


class WindowCleaningSupervisor(Supervisor):

    # Dirt patches sit on the building surface ~5-6 m from centre.
    # Drone orbits at 12 m from centre.
    # Minimum drone-to-dirt distance ≈ 6-7 m  →  radius must exceed that.
    CLEAN_RADIUS    = 7.0    # metres — dirt removed when drone is this close
    CHECK_INTERVAL  = 200    # ms between cleaning checks
    STATUS_INTERVAL = 5000   # ms between status prints
    TOTAL_DIRT      = 389    # DEF DIRT_1 … DIRT_389

    def __init__(self):
        super().__init__()
        self.time_step = int(self.getBasicTimeStep())

        # ── Find the drone node ───────────────────────────────────────
        self.drone = self.getFromDef("MAVIC2PRO")
        if self.drone is None:
            print("⚠️  WARNING: DEF MAVIC2PRO not found.")
            print("   Ensure the Mavic2Pro node has 'DEF MAVIC2PRO' in the .wbt")
        else:
            print("✅ Drone node (MAVIC2PRO) found")

        # ── Collect all dirt nodes via getFromDef (index-safe) ────────
        self.dirt = {}
        self._collect_dirt()

        self.last_check_ms  = 0
        self.last_status_ms = 0
        self.total_cleaned  = 0

        print("=" * 55)
        print("🧹 Window Cleaning Supervisor ready")
        print(f"   Dirt patches found : {len(self.dirt)}")
        print(f"   Clean radius       : {self.CLEAN_RADIUS} m")
        print("=" * 55)

    # ─────────────────────────────────────────────────────────────────
    def _collect_dirt(self):
        """
        Look up every DIRT_N node by DEF name.
        getFromDef() is stable — removing other nodes never shifts its result.
        """
        found = 0
        missing = []

        for i in range(1, self.TOTAL_DIRT + 1):
            def_name = f"DIRT_{i}"
            node = self.getFromDef(def_name)

            if node is None:
                missing.append(def_name)
                continue

            trans_field = node.getField("translation")
            if trans_field is None:
                continue

            pos = np.array(trans_field.getSFVec3f())
            self.dirt[def_name] = {
                "node":    node,
                "pos":     pos,
                "cleaned": False,
            }
            found += 1

        # Sort by height for readable floor-by-floor progress
        self.dirt = dict(
            sorted(self.dirt.items(), key=lambda kv: kv[1]["pos"][2])
        )

        if found > 0:
            heights = [v["pos"][2] for v in self.dirt.values()]
            print(f"   Height range : {min(heights):.1f} m → {max(heights):.1f} m")
            if missing:
                print(f"   ⚠️  {len(missing)} DEF names not found (may be named differently)")
        else:
            print("⚠️  No dirt nodes found — check DEF names in the .wbt file")

    # ─────────────────────────────────────────────────────────────────
    def _get_drone_pos(self):
        """Return numpy [x, y, z] of the drone, or None."""
        if self.drone is None:
            return None
        f = self.drone.getField("translation")
        if f is None:
            return None
        return np.array(f.getSFVec3f())

    # ─────────────────────────────────────────────────────────────────
    def _check_and_clean(self, drone_pos):
        """
        Remove every uncleaned dirt patch within CLEAN_RADIUS of the drone.
        The distance is measured in 3D (x, y, z) so height is accounted for.
        try/except guards against accessing an already-removed node.
        """
        if drone_pos is None:
            return

        cleaned_now = []

        for def_name, info in self.dirt.items():
            if info["cleaned"]:
                continue

            dist = float(np.linalg.norm(drone_pos - info["pos"]))

            if dist <= self.CLEAN_RADIUS:
                try:
                    info["node"].remove()
                    info["cleaned"] = True
                    cleaned_now.append((def_name, dist))
                except Exception as e:
                    # Node was already gone — mark cleaned and move on
                    info["cleaned"] = True
                    print(f"   ℹ️  {def_name} already removed ({e})")

        if cleaned_now:
            self.total_cleaned += len(cleaned_now)
            remaining = sum(1 for v in self.dirt.values() if not v["cleaned"])

            print(f"\n🧹 Cleaned {len(cleaned_now)} patch(es):")
            for def_name, dist in cleaned_now:
                pos = self.dirt[def_name]["pos"]
                print(f"   • {def_name:<14}  dist={dist:.2f} m  z={pos[2]:.1f} m")

            pct = 100 * self.total_cleaned / len(self.dirt)
            print(f"   Progress : {self.total_cleaned}/{len(self.dirt)} "
                  f"({pct:.0f}%)  —  {remaining} remaining")

            if remaining == 0:
                print()
                print("🎉 ══════════════════════════════════════════")
                print("   ALL DIRT PATCHES CLEANED SUCCESSFULLY!")
                print("   ══════════════════════════════════════════")

    # ─────────────────────────────────────────────────────────────────
    def _print_status(self, drone_pos, sim_time):
        remaining = sum(1 for v in self.dirt.values() if not v["cleaned"])
        pct = 100 * self.total_cleaned / max(len(self.dirt), 1)

        if drone_pos is not None:
            pos_str = (f"x={drone_pos[0]:+.1f}  "
                       f"y={drone_pos[1]:+.1f}  "
                       f"z={drone_pos[2]:.1f}")
        else:
            pos_str = "position unknown"

        print(f"[{sim_time:6.1f}s] 🚁 {pos_str}  |  "
              f"🧹 {self.total_cleaned}/{len(self.dirt)} "
              f"({pct:.0f}%)  remaining={remaining}")

    # ─────────────────────────────────────────────────────────────────
    def run(self):
        while self.step(self.time_step) != -1:
            sim_ms    = int(self.getTime() * 1000)
            drone_pos = self._get_drone_pos()

            if sim_ms - self.last_check_ms >= self.CHECK_INTERVAL:
                self.last_check_ms = sim_ms
                self._check_and_clean(drone_pos)

            if sim_ms - self.last_status_ms >= self.STATUS_INTERVAL:
                self.last_status_ms = sim_ms
                self._print_status(drone_pos, self.getTime())


if __name__ == "__main__":
    sup = WindowCleaningSupervisor()
    sup.run()
