from controller import Supervisor
import numpy as np


class WindowCleaningSupervisor(Supervisor):

    # Dirt is on building surface: xy_dist ≈ 4.2–5.2 m from center
    # Drone orbits at xy_dist = 12 m from center
    # → horizontal gap between drone and dirt ≈ 12 - 5.2 = 6.8 m
    # → use XY_THRESHOLD slightly above that gap
    #
    # Dirt spans z = -2 m to 54 m, drone starts at z = 20 m
    # → only clean dirt that is close in HEIGHT too (within Z_THRESHOLD)
    # → this way the drone cleans the correct floor as it spirals up

    XY_THRESHOLD    = 10.0   # metres horizontal distance drone↔dirt
                             # (was 8.0 — old margin over worst-case 7.94 m gap was only 0.06 m,
                             #  any orbit wobble caused a miss; 10.0 gives a safe 2 m margin)
    Z_THRESHOLD     = 3.0    # metres vertical distance drone↔dirt
    CHECK_INTERVAL  = 100    # ms between cleaning checks (fast to not miss dirt)
    STATUS_INTERVAL = 5000   # ms between status prints
    TOTAL_DIRT      = 389    # DEF DIRT_1 … DIRT_389

    def __init__(self):
        super().__init__()
        self.time_step = int(self.getBasicTimeStep())

        # ── Find the drone ────────────────────────────────────────────
        self.drone = self.getFromDef("MAVIC2PRO")
        if self.drone is None:
            print("⚠️  WARNING: DEF MAVIC2PRO not found in scene.")
            print("   Make sure Mavic2Pro node has 'DEF MAVIC2PRO' in the .wbt")
        else:
            print("✅ Drone node (MAVIC2PRO) found")

        # ── Collect dirt nodes via getFromDef (index-safe) ────────────
        self.dirt = {}
        self._collect_dirt()

        self.last_check_ms  = 0
        self.last_status_ms = 0
        self.total_cleaned  = 0

        print("=" * 55)
        print("🧹 Window Cleaning Supervisor ready")
        print(f"   Dirt patches     : {len(self.dirt)}")
        print(f"   XY threshold     : {self.XY_THRESHOLD} m")
        print(f"   Z  threshold     : {self.Z_THRESHOLD} m")
        print("=" * 55)

    # ─────────────────────────────────────────────────────────────────
    def _collect_dirt(self):
        found   = 0
        missing = 0

        for i in range(1, self.TOTAL_DIRT + 1):
            def_name = f"DIRT_{i}"
            node = self.getFromDef(def_name)
            if node is None:
                missing += 1
                continue

            trans_field = node.getField("translation")
            if trans_field is None:
                continue

            pos = np.array(trans_field.getSFVec3f())   # [x, y, z]
            self.dirt[def_name] = {
                "node":    node,
                "pos":     pos,
                "cleaned": False,
            }
            found += 1

        # Sort by z so progress prints floor by floor
        self.dirt = dict(
            sorted(self.dirt.items(), key=lambda kv: kv[1]["pos"][2])
        )

        if found > 0:
            zs = [v["pos"][2] for v in self.dirt.values()]
            ds = [float(np.linalg.norm(v["pos"][:2])) for v in self.dirt.values()]
            print(f"   Height range     : {min(zs):.1f} m → {max(zs):.1f} m")
            print(f"   XY dist range    : {min(ds):.1f} m → {max(ds):.1f} m from center")
        if missing:
            print(f"   ⚠️  {missing} DEF names not found")

    # ─────────────────────────────────────────────────────────────────
    def _get_drone_pos(self):
        if self.drone is None:
            return None
        f = self.drone.getField("translation")
        if f is None:
            return None
        return np.array(f.getSFVec3f())   # [x, y, z]

    # ─────────────────────────────────────────────────────────────────
    def _check_and_clean(self, drone_pos):
        """
        Clean dirt that is:
          • within XY_THRESHOLD metres horizontally  (same wall face)
          • within Z_THRESHOLD  metres vertically    (same floor level)

        Separating XY and Z thresholds is critical because:
          - Drone xy position = 12 m from center
          - Dirt  xy position = ~5 m from center
          - Horizontal gap    = ~7 m  → XY_THRESHOLD must exceed this
          - But we don't want to clean all floors at once, only the
            floor the drone is currently flying at → Z_THRESHOLD = 3 m
        """
        if drone_pos is None:
            return

        drone_xy = drone_pos[:2]   # [x, y]
        drone_z  = drone_pos[2]    # z (altitude)

        cleaned_now = []

        for def_name, info in self.dirt.items():
            if info["cleaned"]:
                continue

            dirt_pos = info["pos"]
            dirt_xy  = dirt_pos[:2]
            dirt_z   = dirt_pos[2]

            # Independent horizontal and vertical distance checks
            xy_dist = float(np.linalg.norm(drone_xy - dirt_xy))
            z_dist  = abs(float(drone_z - dirt_z))

            if xy_dist <= self.XY_THRESHOLD and z_dist <= self.Z_THRESHOLD:
                try:
                    info["node"].remove()
                    info["cleaned"] = True
                    cleaned_now.append((def_name, xy_dist, z_dist))
                except Exception as e:
                    info["cleaned"] = True
                    print(f"   ℹ️  {def_name} already removed ({e})")

        if cleaned_now:
            self.total_cleaned += len(cleaned_now)
            remaining = sum(1 for v in self.dirt.values() if not v["cleaned"])

            print(f"\n🧹 Cleaned {len(cleaned_now)} patch(es):")
            for def_name, xyd, zd in cleaned_now:
                pos = self.dirt[def_name]["pos"]
                print(f"   • {def_name:<14}  xy={xyd:.2f} m  z_diff={zd:.2f} m  "
                      f"height={pos[2]:.1f} m")

            pct = 100 * self.total_cleaned / len(self.dirt)
            print(f"   Progress : {self.total_cleaned}/{len(self.dirt)} "
                  f"({pct:.0f}%)  —  {remaining} remaining")

            if remaining == 0:
                print()
                print("🎉 ══════════════════════════════════════════")
                print("   ALL DIRT PATCHES CLEANED SUCCESSFULLY!")
                print("   ══════════════════════════════════════════")

    # ─────────────────────────────────────────────────────────────────
    def _print_status(self, drone_pos, sim_time):
        remaining = sum(1 for v in self.dirt.values() if not v["cleaned"])
        pct = 100 * self.total_cleaned / max(len(self.dirt), 1)

        if drone_pos is not None:
            # Also show what dirt is nearby right now for debugging
            drone_xy = drone_pos[:2]
            drone_z  = drone_pos[2]
            nearby = []
            for name, info in self.dirt.items():
                if info["cleaned"]:
                    continue
                xyd = float(np.linalg.norm(drone_xy - info["pos"][:2]))
                zd  = abs(float(drone_z - info["pos"][2]))
                if xyd < 10 and zd < 5:
                    nearby.append(f"{name}(xy={xyd:.1f} z={zd:.1f})")

            pos_str = (f"x={drone_pos[0]:+.1f} y={drone_pos[1]:+.1f} "
                       f"z={drone_pos[2]:.1f}")
            nearby_str = ", ".join(nearby[:3]) if nearby else "none in range"
        else:
            pos_str    = "unknown"
            nearby_str = "—"

        print(f"[{sim_time:6.1f}s] 🚁 {pos_str}  |  "
              f"🧹 {self.total_cleaned}/{len(self.dirt)} ({pct:.0f}%)  "
              f"remaining={remaining}  nearby={nearby_str}")

    # ─────────────────────────────────────────────────────────────────
    def run(self):
        while self.step(self.time_step) != -1:
            sim_ms    = int(self.getTime() * 1000)
            drone_pos = self._get_drone_pos()

            if sim_ms - self.last_check_ms >= self.CHECK_INTERVAL:
                self.last_check_ms = sim_ms
                self._check_and_clean(drone_pos)

            if sim_ms - self.last_status_ms >= self.STATUS_INTERVAL:
                self.last_status_ms = sim_ms
                self._print_status(drone_pos, self.getTime())


if __name__ == "__main__":
    sup = WindowCleaningSupervisor()
    sup.run()
