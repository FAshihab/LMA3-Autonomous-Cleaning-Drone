from controller import Robot
import numpy as np

def clamp(value, value_min, value_max):
    return min(max(value, value_min), value_max)


class Mavic(Robot):
    # ── Flight PID constants ───────────────────────────────────────────
    K_VERTICAL_THRUST     = 68.5
    K_VERTICAL_OFFSET     = 0.6
    K_VERTICAL_P          = 3.0
    K_ROLL_P              = 50.0
    K_PITCH_P             = 30.0
    MAX_YAW_DISTURBANCE   = 0.4
    MAX_PITCH_DISTURBANCE = -1.0

    # ── Orbit / mission settings ───────────────────────────────────────
    BUILDING_CENTER = [0.0, 0.0]   # BigGlassTower is at world origin
    ORBIT_RADIUS    = 12.0         # metres from building centre
    ORBIT_SPEED     = 0.006        # radians per time step
    TARGET_ALTITUDE = 2.0          # starting patrol height (m) — start at bottom so low-altitude dirt is covered
    ALTITUDE_STEP   = 1.5          # metres to climb after each full lap
    MAX_ALTITUDE    = 55.0         # top of BigGlassTower ~55 m

    # ── Wall safety ────────────────────────────────────────────────────
    # wall_sensor lookupTable max is 5 m — use 3 m as safe threshold
    SAFE_WALL_DIST  = 1.5         # metres — push back below this (sensor range now 10 m; building ~7 m away)
    PUSHBACK_GAIN   = 3.0          # pushback pitch strength

    def __init__(self):
        super(Mavic, self).__init__()
        self.time_step = int(self.getBasicTimeStep())

        # ── Sensors ───────────────────────────────────────────────────
        self.imu = self.getDevice("inertial unit")
        self.imu.enable(self.time_step)

        self.gps = self.getDevice("gps")
        self.gps.enable(self.time_step)

        self.gyro = self.getDevice("gyro")
        self.gyro.enable(self.time_step)

        self.wall_sensor = self.getDevice("wall_sensor")
        self.wall_sensor.enable(self.time_step)

        # ── Motors ────────────────────────────────────────────────────
        self.front_left_motor  = self.getDevice("front left propeller")
        self.front_right_motor = self.getDevice("front right propeller")
        self.rear_left_motor   = self.getDevice("rear left propeller")
        self.rear_right_motor  = self.getDevice("rear right propeller")

        for motor in [self.front_left_motor, self.front_right_motor,
                      self.rear_left_motor,  self.rear_right_motor]:
            motor.setPosition(float('inf'))
            motor.setVelocity(1)

        # ── State ─────────────────────────────────────────────────────
        self.pose         = [0.0] * 6
        self.orbit_angle  = 0.0
        self.target_alt   = self.TARGET_ALTITUDE
        self.laps_done    = 0
        self.angle_at_lap = 0.0

        print("🚀 Drone controller started")
        print(f"   Orbit radius   : {self.ORBIT_RADIUS} m")
        print(f"   Safe wall dist : {self.SAFE_WALL_DIST} m")
        print(f"   Start altitude : {self.TARGET_ALTITUDE} m")
        print(f"   Max altitude   : {self.MAX_ALTITUDE} m")

    # ── Motor mixing ──────────────────────────────────────────────────
    def _set_motors(self, vertical, yaw, pitch, roll):
        MAX = 550
        fl = clamp(self.K_VERTICAL_THRUST + vertical - yaw + pitch - roll, -MAX, MAX)
        fr = clamp(self.K_VERTICAL_THRUST + vertical + yaw + pitch + roll, -MAX, MAX)
        rl = clamp(self.K_VERTICAL_THRUST + vertical + yaw - pitch - roll, -MAX, MAX)
        rr = clamp(self.K_VERTICAL_THRUST + vertical - yaw - pitch + roll, -MAX, MAX)
        self.front_left_motor.setVelocity( fl)
        self.front_right_motor.setVelocity(-fr)
        self.rear_left_motor.setVelocity(  -rl)
        self.rear_right_motor.setVelocity(  rr)

    def _stop_motors(self):
        for m in [self.front_left_motor, self.front_right_motor,
                  self.rear_left_motor,  self.rear_right_motor]:
            m.setVelocity(0)

    # ── Altitude PID ──────────────────────────────────────────────────
    def _altitude_control(self, altitude):
        err = clamp(self.target_alt - altitude + self.K_VERTICAL_OFFSET, -1, 1)
        return self.K_VERTICAL_P * (err ** 3)

    # ── Next point on the orbit circle ────────────────────────────────
    def _orbit_target_xy(self):
        cx, cy = self.BUILDING_CENTER
        tx = cx + self.ORBIT_RADIUS * np.cos(self.orbit_angle)
        ty = cy + self.ORBIT_RADIUS * np.sin(self.orbit_angle)
        return tx, ty

    # ── Orbit controller ──────────────────────────────────────────────
    def _orbit_control(self):
        tx, ty = self._orbit_target_xy()
        dx = tx - self.pose[0]
        dy = ty - self.pose[1]
        dist_to_point = np.sqrt(dx**2 + dy**2)

        angle_to_point = np.arctan2(dy, dx)
        angle_err = angle_to_point - self.pose[5]
        angle_err = (angle_err + np.pi) % (2 * np.pi) - np.pi

        yaw_dist = self.MAX_YAW_DISTURBANCE * clamp(angle_err / np.pi, -1, 1)

        wall_dist = self.wall_sensor.getValue()

        if wall_dist < self.SAFE_WALL_DIST:
            # Too close — push away from building
            closeness  = (self.SAFE_WALL_DIST - wall_dist) / self.SAFE_WALL_DIST
            pitch_dist = self.PUSHBACK_GAIN * closeness
            print(f"⚠️  Wall close! sensor={wall_dist:.2f} m — pushing back")
        elif abs(angle_err) < 0.6 and dist_to_point > 0.3:
            speed      = clamp(dist_to_point / 5.0, 0.2, 1.0)
            pitch_dist = self.MAX_PITCH_DISTURBANCE * speed
        else:
            pitch_dist = 0.0

        return yaw_dist, pitch_dist

    # ── Advance orbit angle; climb after each full lap ────────────────
    def _advance_orbit(self):
        self.orbit_angle += self.ORBIT_SPEED
        if self.orbit_angle - self.angle_at_lap >= 2 * np.pi:
            self.angle_at_lap = self.orbit_angle
            self.laps_done   += 1
            self.target_alt   = min(
                self.TARGET_ALTITUDE + self.laps_done * self.ALTITUDE_STEP,
                self.MAX_ALTITUDE
            )
            print(f"🔄 Lap {self.laps_done} complete — climbing to {self.target_alt:.1f} m")

    # ── Main loop ─────────────────────────────────────────────────────
    def run(self):
        while self.step(self.time_step) != -1:

            roll, pitch, yaw       = self.imu.getRollPitchYaw()
            x_pos, y_pos, alt      = self.gps.getValues()
            roll_acc, pitch_acc, _ = self.gyro.getValues()
            self.pose = [x_pos, y_pos, alt, roll, pitch, yaw]

            # Flip guard
            tilt = np.sqrt(roll**2 + pitch**2)
            if tilt > 1.0:
                print(f"💥 Flip! roll={np.degrees(roll):.1f}° pitch={np.degrees(pitch):.1f}°")
                self._stop_motors()
                continue

            vertical = self._altitude_control(alt)

            # Takeoff phase — gentle inputs until 2 m
            if alt < 2.0:
                roll_i  = clamp(self.K_ROLL_P  * clamp(roll,  -0.1, 0.1) + roll_acc,  -5, 5)
                pitch_i = clamp(self.K_PITCH_P * clamp(pitch, -0.1, 0.1) + pitch_acc, -5, 5)
                self._set_motors(vertical, 0, pitch_i, roll_i)
                continue

            # Normal flight — orbit
            roll_i  = self.K_ROLL_P  * clamp(roll,  -1, 1) + roll_acc
            pitch_i = self.K_PITCH_P * clamp(pitch, -1, 1) + pitch_acc

            yaw_dist, pitch_dist = self._orbit_control()
            pitch_i += pitch_dist

            self._set_motors(vertical, yaw_dist, pitch_i, roll_i)
            self._advance_orbit()


if __name__ == "__main__":
    robot = Mavic()
    robot.run()
