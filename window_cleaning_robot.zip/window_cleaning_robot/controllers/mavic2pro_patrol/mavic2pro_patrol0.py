from controller import Robot
import numpy as np

def clamp(value, value_min, value_max):
    return min(max(value, value_min), value_max)


class Mavic(Robot):
    # ── Flight constants ───────────────────────────────────────────────
    K_VERTICAL_THRUST     = 68.5
    K_VERTICAL_OFFSET     = 0.6
    K_VERTICAL_P          = 3.0
    K_ROLL_P              = 50.0
    K_PITCH_P             = 30.0
    MAX_YAW_DISTURBANCE   = 0.4
    MAX_PITCH_DISTURBANCE = -1.0

    # ── Mission constants ──────────────────────────────────────────────
    ORBIT_RADIUS    = 8.0     # metres from building centre
    ORBIT_SPEED     = 0.008   # radians per step
    TARGET_ALTITUDE = 20.0    # starting patrol altitude (m)
    ALTITUDE_STEP   = 1.5     # metres gained per completed lap
    MAX_ALTITUDE    = 55.0    # top of BigGlassTower
    BUILDING_CENTER = [0.0, 0.0]

    def __init__(self):
        super().__init__()
        self.time_step = int(self.getBasicTimeStep())

        # ── Sensors ───────────────────────────────────────────────────
        self.imu = self.getDevice("inertial unit")
        self.imu.enable(self.time_step)

        self.gps = self.getDevice("gps")
        self.gps.enable(self.time_step)

        self.gyro = self.getDevice("gyro")
        self.gyro.enable(self.time_step)

        self.wall_sensor = self.getDevice("wall_sensor")
        self.wall_sensor.enable(self.time_step)

        # ── Motors ────────────────────────────────────────────────────
        self.fl = self.getDevice("front left propeller")
        self.fr = self.getDevice("front right propeller")
        self.rl = self.getDevice("rear left propeller")
        self.rr = self.getDevice("rear right propeller")
        for m in [self.fl, self.fr, self.rl, self.rr]:
            m.setPosition(float('inf'))
            m.setVelocity(1)

        # ── State ─────────────────────────────────────────────────────
        self.pose         = [0.0] * 6   # x y z roll pitch yaw
        self.orbit_angle  = 0.0         # current angle around building (rad)
        self.target_alt   = self.TARGET_ALTITUDE
        self.laps_done    = 0
        self.angle_at_lap = 0.0         # angle reference for lap detection

        print("🚀 Drone controller started")
        print(f"   Orbit radius : {self.ORBIT_RADIUS} m")
        print(f"   Start altitude: {self.TARGET_ALTITUDE} m")
        print(f"   Max altitude  : {self.MAX_ALTITUDE} m")

    # ── Motor mixing ──────────────────────────────────────────────────
    def set_motors(self, vertical, yaw, pitch, roll):
        MAX = 550
        fl = clamp(self.K_VERTICAL_THRUST + vertical - yaw + pitch - roll, -MAX, MAX)
        fr = clamp(self.K_VERTICAL_THRUST + vertical + yaw + pitch + roll, -MAX, MAX)
        rl = clamp(self.K_VERTICAL_THRUST + vertical + yaw - pitch - roll, -MAX, MAX)
        rr = clamp(self.K_VERTICAL_THRUST + vertical - yaw - pitch + roll, -MAX, MAX)
        self.fl.setVelocity( fl)
        self.fr.setVelocity(-fr)
        self.rl.setVelocity(-rl)
        self.rr.setVelocity( rr)

    # ── Current target point on orbit circle ──────────────────────────
    def orbit_target_xy(self):
        cx, cy = self.BUILDING_CENTER
        tx = cx + self.ORBIT_RADIUS * np.cos(self.orbit_angle)
        ty = cy + self.ORBIT_RADIUS * np.sin(self.orbit_angle)
        return tx, ty

    # ── Horizontal position controller ────────────────────────────────
    def position_control(self):
        tx, ty = self.orbit_target_xy()
        dx = tx - self.pose[0]
        dy = ty - self.pose[1]
        dist = np.sqrt(dx**2 + dy**2)

        angle_to_point = np.arctan2(dy, dx)
        angle_err = angle_to_point - self.pose[5]
        angle_err = (angle_err + np.pi) % (2 * np.pi) - np.pi   # wrap [-π, π]

        yaw_dist = self.MAX_YAW_DISTURBANCE * clamp(angle_err / np.pi, -1, 1)

        # Pitch forward only when roughly aligned and far from target point
        if abs(angle_err) < 0.6 and dist > 0.3:
            speed     = clamp(dist / 5.0, 0, 1)
            pitch_dist = self.MAX_PITCH_DISTURBANCE * speed
        else:
            pitch_dist = 0.0

        return yaw_dist, pitch_dist

    # ── Altitude PID ──────────────────────────────────────────────────
    def altitude_control(self, altitude):
        err = clamp(self.target_alt - altitude + self.K_VERTICAL_OFFSET, -1, 1)
        return self.K_VERTICAL_P * (err ** 3)

    # ── Advance orbit angle; raise altitude after each full lap ───────
    def advance_orbit(self):
        self.orbit_angle += self.ORBIT_SPEED

        if self.orbit_angle - self.angle_at_lap >= 2 * np.pi:
            self.angle_at_lap = self.orbit_angle
            self.laps_done   += 1
            self.target_alt   = min(
                self.TARGET_ALTITUDE + self.laps_done * self.ALTITUDE_STEP,
                self.MAX_ALTITUDE
            )
            print(f"🔄 Lap {self.laps_done} done — new target altitude: {self.target_alt:.1f} m")

    # ── Main loop ─────────────────────────────────────────────────────
    def run(self):
        while self.step(self.time_step) != -1:

            # Read sensors
            roll, pitch, yaw = self.imu.getRollPitchYaw()
            x, y, altitude   = self.gps.getValues()
            gx, gy, _        = self.gyro.getValues()
            self.pose = [x, y, altitude, roll, pitch, yaw]

            # ── Flip / crash guard ────────────────────────────────────
            tilt = np.sqrt(roll**2 + pitch**2)
            if tilt > 1.0:
                print(f"💥 Flip detected! tilt={np.degrees(tilt):.1f}° — cutting motors")
                for m in [self.fl, self.fr, self.rl, self.rr]:
                    m.setVelocity(0)
                continue

            # ── Takeoff phase (below 2 m): very gentle inputs ─────────
            if altitude < 2.0:
                roll_i  = clamp(self.K_ROLL_P  * clamp(roll,  -0.1, 0.1) + gx, -5, 5)
                pitch_i = clamp(self.K_PITCH_P * clamp(pitch, -0.1, 0.1) + gy, -5, 5)
                vert_i  = self.altitude_control(altitude)
                self.set_motors(vert_i, 0, pitch_i, roll_i)
                continue

            # ── Normal flight ─────────────────────────────────────────
            roll_i  = self.K_ROLL_P  * clamp(roll,  -1, 1) + gx
            pitch_i = self.K_PITCH_P * clamp(pitch, -1, 1) + gy
            vert_i  = self.altitude_control(altitude)

            yaw_dist, pitch_dist = self.position_control()
            pitch_i += pitch_dist

            self.set_motors(vert_i, yaw_dist, pitch_i, roll_i)

            # Advance the orbit angle and handle lap/altitude logic
            self.advance_orbit()


if __name__ == "__main__":
    robot = Mavic()
    robot.run()
